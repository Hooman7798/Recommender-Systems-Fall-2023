import { useQuery } from "@tanstack/react-query";
import { Rating } from "react-simple-star-rating";

const ItemCard = (props) => {
  const { id, onRating, ...rest } = props;

  // const { isPending, error, data } = useQuery({
  //   queryKey: [title],
  //   queryFn: () =>
  //     fetch(
  //       `http://www.omdbapi.com/?i=tt3896198&apikey=56563b98=${title.slice(
  //         0,
  //         -7
  //       )}`
  //     ).then((res) => res.json()),
  // });

  return (
    <div className="bg-white shadow-xl w-[170px] rounded-md  ">
      {/* <img className="w-full mb-3 h-[170px] rounded-md" src={data?.Poster} /> */}
      <p className="text-xs mb-1 text-gray-500 px-1">{id}</p>

      {!!onRating && (
        <div className="w-full pb-1">
          <Rating onClick={onRating} size={20} allowFraction />
        </div>
      )}
    </div>
  );
};
export default ItemCard;
