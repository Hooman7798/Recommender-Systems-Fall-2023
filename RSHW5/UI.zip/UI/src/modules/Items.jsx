import { useQuery, useMutation } from "@tanstack/react-query";
import axios from "axios";
import ItemCard from "../components/ItemCard";

const Items = () => {
  const { isPending, error, data } = useQuery({
    queryKey: ["movies_data"],
    queryFn: () =>
      fetch("http://127.0.0.1:8000/movies").then((res) => res.json()),
  });

  const { isLoading, isSuccess, mutate } = useMutation({
    mutationFn: (payload) => axios.post("http://127.0.0.1:8000/rate", payload),
  });

  return (
    <div>
      <div className="flex flex-wrap justify-center gap-5">
        {data?.data?.map((item) => (
          <ItemCard
            id={item?.id}
            onRating={(rate) => {
              mutate({ id: item?.id, rate: rate });
            }}
          />
        ))}
      </div>
    </div>
  );
};
export default Items;
