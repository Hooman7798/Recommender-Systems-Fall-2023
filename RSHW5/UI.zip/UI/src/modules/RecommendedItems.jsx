import { useQuery, useQueryClient } from "@tanstack/react-query";
import ItemCard from "../components/ItemCard";

const RecommendedItems = () => {
  const queryClient = useQueryClient();

  const { isPending, error, data } = useQuery({
    queryKey: ["recom_movies_data"],
    queryFn: () =>
      fetch("http://127.0.0.1:8000/recom-movie").then((res) => res.json()),
  });

  return (
    <div className="-mt-10">
      <p className="font-bold text-red-400 text-lg">
        {" "}
        Our Recommendation To You
      </p>
      <div className="flex flex-wrap justify-center gap-5 bg-gray-400 rounded-md p-5 mb-10 ">
        {data?.data?.map((item) => (
          <ItemCard id={item?.id} />
        ))}
        <button
          className="bg-white p-2 text-sm rounded-md"
          onClick={() => {
            queryClient.invalidateQueries(["recom_movies_data"]);
          }}
        >
          Recommend
        </button>
      </div>
    </div>
  );
};
export default RecommendedItems;
